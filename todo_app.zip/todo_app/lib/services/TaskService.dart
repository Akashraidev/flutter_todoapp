import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/task.dart';
import '../utils/AppError.dart';

class TaskService {
  static const String baseUrl = 'BASE_URL';

  Future<List<Task>> getTasks(String token) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/tasks'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((json) => Task.fromJson(json)).toList();
      } else if (response.statusCode == 400) {
        throw AuthException('Unauthorized');
      } else {
        throw NetworkException(
          'Failed to load tasks',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      if (e is AuthException || e is NetworkException) rethrow;
      throw NetworkException('Network error: ${e.toString()}');
    }
  }

  Future<Task> createTask(String token, String title, String description) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/tasks'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'title': title,
          'description': description,
        }),
      );

      if ( response.statusCode == 200) {
        return Task.fromJson(jsonDecode(response.body));
      } else if (response.statusCode == 400) {
        throw AuthException('Unauthorized');
      } else {
        throw NetworkException(
          'Failed to create task',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      if (e is AuthException || e is NetworkException) rethrow;
      throw NetworkException('Network error: ${e.toString()}');
    }
  }

  Future<Task> updateTask(String token, String taskId, String title, String description) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/tasks/$taskId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'title': title,
          'description': description,
        }),
      );

      if (response.statusCode == 200) {
        return Task.fromJson(jsonDecode(response.body));
      } else if (response.statusCode == 400) {
        throw AuthException('Unauthorized');
      } else {
        throw NetworkException(
          'Failed to update task',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      if (e is AuthException || e is NetworkException) rethrow;
      throw NetworkException('Network error: ${e.toString()}');
    }
  }

  Future<void> deleteTask(String token, String taskId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/tasks/$taskId'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 400) {
        throw AuthException('Unauthorized');
      } else if (response.statusCode != 200 && response.statusCode != 204) {
        throw NetworkException(
          'Failed to delete task',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      if (e is AuthException || e is NetworkException) rethrow;
      throw NetworkException('Network error: ${e.toString()}');
    }
  }

  Future<Task> toggleTask(String token, String taskId, bool isCompleted) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/tasks/$taskId/toggle'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'is_completed': isCompleted,
        }),
      );

      if (response.statusCode == 200) {
        return Task.fromJson(jsonDecode(response.body));
      } else if (response.statusCode == 400) {
        throw AuthException('Unauthorized');
      } else {
        throw NetworkException(
          'Failed to toggle task',
          statusCode: response.statusCode,
        );
      }
    } catch (e) {
      if (e is AuthException || e is NetworkException) rethrow;
      throw NetworkException('Network error: ${e.toString()}');
    }
  }
}