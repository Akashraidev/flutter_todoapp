import 'package:flutter/foundation.dart';
import '../models/task.dart';
import '../services/TaskService.dart';
import '../utils/AppError.dart';

import 'auth_provider.dart';

class TaskProvider with ChangeNotifier {
  final TaskService _taskService = TaskService();
  final AuthProvider _authProvider;

  List<Task> _tasks = [];
  bool _isLoading = false;
  String? _error;

  List<Task> get tasks => _tasks;
  bool get isLoading => _isLoading;
  String? get error => _error;

  TaskProvider(this._authProvider);

  // Fetch all tasks
  Future<void> fetchTasks() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final token = _authProvider.accessToken;
      if (token == null) throw AuthException('Not authenticated');

      _tasks = await _taskService.getTasks(token);
      _isLoading = false;
      notifyListeners();
    } on AuthException catch (_) {
      // Try to refresh token
      final refreshed = await _authProvider.refreshAccessToken();
      if (refreshed) {
        await fetchTasks(); // Retry
      } else {
        _error = 'Session expired. Please login again.';
        _isLoading = false;
        notifyListeners();
      }
    } on NetworkException catch (e) {
      _error = e.message;
      _isLoading = false;
      notifyListeners();
    }
  }

  // Create a new task
  Future<bool> createTask(String title, String description) async {
    _error = null;
    notifyListeners();

    try {
      final token = _authProvider.accessToken;
      if (token == null) throw AuthException('Not authenticated');

      final newTask = await _taskService.createTask(token, title, description);
      _tasks.insert(0, newTask);
      notifyListeners();
      return true;
    } on AuthException catch (_) {
      final refreshed = await _authProvider.refreshAccessToken();
      if (refreshed) {
        return await createTask(title, description);
      } else {
        _error = 'Session expired. Please login again.';
        notifyListeners();
        return false;
      }
    } on NetworkException catch (e) {
      _error = e.message;
      notifyListeners();
      return false;
    }
  }

  // Update a task
  Future<bool> updateTask(String taskId, String title, String description) async {
    _error = null;
    notifyListeners();

    try {
      final token = _authProvider.accessToken;
      if (token == null) throw AuthException('Not authenticated');

      final updatedTask = await _taskService.updateTask(token, taskId, title, description);
      final index = _tasks.indexWhere((t) => t.id == taskId);
      if (index != -1) {
        _tasks[index] = updatedTask;
        notifyListeners();
      }
      return true;
    } on AuthException catch (_) {
      final refreshed = await _authProvider.refreshAccessToken();
      if (refreshed) {
        return await updateTask(taskId, title, description);
      } else {
        _error = 'Session expired. Please login again.';
        notifyListeners();
        return false;
      }
    } on NetworkException catch (e) {
      _error = e.message;
      notifyListeners();
      return false;
    }
  }

  // Delete a task
  Future<bool> deleteTask(String taskId) async {
    _error = null;
    notifyListeners();

    try {
      final token = _authProvider.accessToken;
      if (token == null) throw AuthException('Not authenticated');

      await _taskService.deleteTask(token, taskId);
      _tasks.removeWhere((t) => t.id == taskId);
      notifyListeners();
      return true;
    } on AuthException catch (_) {
      final refreshed = await _authProvider.refreshAccessToken();
      if (refreshed) {
        return await deleteTask(taskId);
      } else {
        _error = 'Session expired. Please login again.';
        notifyListeners();
        return false;
      }
    } on NetworkException catch (e) {
      _error = e.message;
      notifyListeners();
      return false;
    }
  }

  // Toggle task completion
  Future<bool> toggleTask(String taskId, bool isCompleted) async {
    _error = null;

    try {
      final token = _authProvider.accessToken;
      if (token == null) throw AuthException('Not authenticated');

      final updatedTask = await _taskService.toggleTask(token, taskId, isCompleted);
      final index = _tasks.indexWhere((t) => t.id == taskId);
      if (index != -1) {
        _tasks[index] = updatedTask;
        notifyListeners();
      }
      return true;
    } on AuthException catch (_) {
      final refreshed = await _authProvider.refreshAccessToken();
      if (refreshed) {
        return await toggleTask(taskId, isCompleted);
      } else {
        _error = 'Session expired. Please login again.';
        notifyListeners();
        return false;
      }
    } on NetworkException catch (e) {
      _error = e.message;
      notifyListeners();
      return false;
    }
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}